/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 * Represents a single message.
 * Updated to align with new MessageManager and MessageStorage requirements.
 */
public class Message {

    // UNUSED generated constructor (kept for safety)
    Message(String string, int i, String string0, String hi_Keegan_did_you_receive_the_payment) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public enum Status { SENT, DISREGARDED, STORED }

    private String id;              // Message ID (10-digit)
    private int number;             // Message number/index
    private String sender;          // NEW — required by MessageManager
    private String recipient;       // Recipient cell number
    private String content;         // Message text
    private String hash;            // Auto-generated message hash
    private Status status;

    // ==========================================================
    // Constructors
    // ==========================================================

    // Constructor for creating a new outgoing message
    public Message(int number, String sender, String recipient, String content) {
        this.number = number;
        this.sender = sender;
        this.recipient = recipient;
        this.content = content;

        this.id = generateMessageId();
        this.hash = createMessageHash();
        this.status = Status.STORED;
    }

    // Constructor for loading stored message
    public Message(String id, int number, String sender, String recipient,
                   String content, Status status) {
        this.id = id;
        this.number = number;
        this.sender = sender;
        this.recipient = recipient;
        this.content = content;

        this.hash = createMessageHash();
        this.status = (status == null ? Status.STORED : status);
    }

    // ==========================================================
    // ID & Hash Generation
    // ==========================================================

    public static String generateMessageId() {
        Random rnd = new Random();
        long v = Math.abs(rnd.nextLong()) % 1_000_000_0000L;
        return String.format("%010d", v);
    }

    public boolean checkMessageID() {
        return this.id != null && this.id.matches("\\d{10}");
    }

    public boolean checkRecipientCell() {
        return this.recipient != null && this.recipient.matches("^\\+27\\d{9}$");
    }

    public String createMessageHash() {
        String firstTwo = (this.id != null && this.id.length() >= 2)
                ? this.id.substring(0, 2)
                : "00";

        String combined = "";
        if (this.content != null && !this.content.trim().isEmpty()) {
            String[] parts = this.content.trim().split("\\s+");
            String first = parts[0].replaceAll("[^A-Za-z0-9]", "");
            String last = parts.length > 1 ? parts[parts.length - 1].replaceAll("[^A-Za-z0-9]", "") : first;
            combined = (first + last).toUpperCase();
        }

        return String.format("%s:%d:%s", firstTwo, this.number, combined);
    }

    // ==========================================================
    // Message Actions
    // ==========================================================

    public static String validateMessageLength(String text) {
        if (text == null) text = "";
        int len = text.length();
        if (len <= 250) return "Message ready to send.";
        int excess = len - 250;
        return String.format("Message exceeds 250 characters by %d.", excess);
    }

    public String performAction(int actionCode) {
        switch (actionCode) {
            case 0:
                this.status = Status.SENT;
                return "Message successfully sent.";
            case 1:
                this.status = Status.DISREGARDED;
                return "Message disregarded.";
            case 2:
                this.status = Status.STORED;
                return "Message stored for later.";
            default:
                return "Unknown action.";
        }
    }

    public String sendMessageViaDialog() {
        Object[] options = {"Send message", "Disregard Message", "Store Message"};
        int choice = JOptionPane.showOptionDialog(null,
                "Choose what to do with the message:",
                "Message Options",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]);
        return performAction(choice);
    }

    // ==========================================================
    // Printing Methods
    // ==========================================================

    public String printMessageDetails() {
        return String.format(
                "Message ID: %s\nSender: %s\nRecipient: %s\nMessage: %s\nStatus: %s",
                this.id, this.sender, this.recipient, this.content,
                (this.status == null ? "UNKNOWN" : this.status)
        );
    }

    public static int returnTotalMessages(List<Message> list) {
        if (list == null) return 0;
        int count = 0;
        for (Message m : list)
            if (m.status == Status.SENT)
                count++;
        return count;
    }

    public static String printMessages(List<Message> list) {
        if (list == null || list.isEmpty()) return "No messages.";
        StringBuilder sb = new StringBuilder();
        for (Message m : list) {
            sb.append(m.printMessageDetails());
            sb.append("\n-----------------\n");
        }
        return sb.toString();
    }

    // ==========================================================
    // Getters & Setters (Updated for new system)
    // ==========================================================

    public String getId() { return id; }
    public int getNumber() { return number; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getContent() { return content; }
    public String getHash() { return hash; }
    public Status getStatus() { return status; }

    public void setStatus(Status status) { this.status = status; }

    public boolean isSent() { return this.status == Status.SENT; }
    public boolean isStored() { return this.status == Status.STORED; }
}
