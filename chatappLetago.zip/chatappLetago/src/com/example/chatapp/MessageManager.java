/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MessageManager {

    private ArrayList<Message> messages;
    private MessageStorage storage;

    public MessageManager() {
        storage = new MessageStorage();
        messages = (ArrayList<Message>) storage.loadMessages();  // Load from JSON file
    }

    public void sendMessage(Message message) {
        messages.add(message);
        storage.saveMessages(messages);
    }

    public ArrayList<Message> getMessages() {
        return messages;
    }

    // ---------------------------------------------------------
    // a. Display sender + recipient for all messages
    // ---------------------------------------------------------
    public void displaySendersAndRecipients() {
        System.out.println("---- SENDERS & RECIPIENTS ----");
        for (Message msg : messages) {
            System.out.println("Sender: " + msg.getSender()
                    + "   Recipient: " + msg.getRecipient());
        }
    }

    // ---------------------------------------------------------
    // b. Longest message
    // ---------------------------------------------------------
    public Message getLongestMessage() {
        if (messages.isEmpty()) {
            return null;
        }

        Message longest = messages.get(0);
        for (Message msg : messages) {
            if (msg.getContent().length() > longest.getContent().length()) {
                longest = msg;
            }
        }
        return longest;
    }

    // ---------------------------------------------------------
    // c. Search message by ID
    // ---------------------------------------------------------
    public Message searchById(String id) {
        for (Message msg : messages) {
            if (msg.getId().equals(id)) {
                return msg;
            }
        }
        return null;
    }

    // ---------------------------------------------------------
    // d. Search all messages sent to one recipient
    // ---------------------------------------------------------
    public List<Message> searchByRecipient(String recipient) {
        List<Message> results = new ArrayList<>();
        for (Message msg : messages) {
            if (msg.getRecipient().equalsIgnoreCase(recipient)) {
                results.add(msg);
            }
        }
        return results;
    }

    // ---------------------------------------------------------
    // e. Delete a message using its hash
    // ---------------------------------------------------------
    public boolean deleteByHash(String hash) {
        Iterator<Message> iterator = messages.iterator();

        while (iterator.hasNext()) {
            Message msg = iterator.next();
            if (msg.getHash().equals(hash)) {
                iterator.remove();
                storage.saveMessages(messages); // persist deletion
                return true;
            }
        }
        return false;
    }

    // ---------------------------------------------------------
    // f. Display full report of all messages
    // ---------------------------------------------------------
    public void displayFullReport() {
        System.out.println("---- FULL MESSAGE REPORT ----");
        for (Message msg : messages) {
            System.out.println("Message ID: " + msg.getId());
            System.out.println("Sender: " + msg.getSender());
            System.out.println("Recipient: " + msg.getRecipient());
            System.out.println("Content: " + msg.getContent());
            System.out.println("Hash: " + msg.getHash());
            System.out.println("------------------------------");
        }
    }
}