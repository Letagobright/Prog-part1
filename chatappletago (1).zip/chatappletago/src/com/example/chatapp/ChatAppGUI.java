/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;





/**
 *
 * @author hifi
 */
public class ChatAppGUI {
    public static void main(String[] args) {
        // === GLOBAL UI SETTINGS ===
        UIManager.put("OptionPane.background", Color.BLACK);
        UIManager.put("Panel.background", Color.BLACK);
        UIManager.put("OptionPane.messageForeground", Color.YELLOW);
        UIManager.put("OptionPane.border", new LineBorder(new Color(255, 102, 102), 4)); // light red
        UIManager.put("Button.background", Color.BLACK);
        UIManager.put("Button.foreground", Color.YELLOW);

        login login = new login();

        // === LOGO & WELCOME ===
        showWelcomeScreen();

        // === REGISTRATION ===
        while (true) {
            JOptionPane.showMessageDialog(null, 
                "📝 Let's get you started!\nPlease fill in your details below.",
                "Registration", JOptionPane.INFORMATION_MESSAGE);

            String username = JOptionPane.showInputDialog(null,
                    "Choose a username (must contain '_' and be no more than 5 characters):");
            if (username == null) return;

            String password = JOptionPane.showInputDialog(null,
                    "Set a password (min 8 chars, 1 capital letter, 1 number, 1 symbol):");
            if (password == null) return;

            String cellphone = JOptionPane.showInputDialog(null,
                    "Enter your cellphone number (with international code, e.g. ‪+27831234567‬):");
            if (cellphone == null) return;

            String regMessage = login.registerUser(username.trim(), password, cellphone.trim());
            JOptionPane.showMessageDialog(null, regMessage);

            if (regMessage.equals("Registration successful.")) break;
        }

        // === LOGIN ===
        boolean loggedIn = false;
        String loggedUsername = null;
        while (!loggedIn) {
            JOptionPane.showMessageDialog(null, 
                "🔐 Please log in to continue.",
                "Login", JOptionPane.INFORMATION_MESSAGE);

            String username = JOptionPane.showInputDialog(null, "Enter your username:");
            if (username == null) return;

            String password = JOptionPane.showInputDialog(null, "Enter your password:");
            if (password == null) return;

            boolean ok = login.loginUser(username.trim(), password);
            String msg = login.returnLoginStatus(ok, username.trim());
            JOptionPane.showMessageDialog(null, msg);

            if (ok) {
                loggedIn = true;
                loggedUsername = username.trim();
            }
        }

        // === WELCOME AFTER LOGIN ===
        JOptionPane.showMessageDialog(null,
                "🌟 Welcome aboard, " + loggedUsername + "!\n\nWhere chats meet lightning speed ⚡",
                "LMQuickChat", JOptionPane.INFORMATION_MESSAGE);

        // === MESSAGE COUNT INPUT ===
        int messagesToEnter = 0;
        while (messagesToEnter <= 0) {
            String nm = JOptionPane.showInputDialog(null,
                    "📨 How many messages would you like to send today?");
            if (nm == null) return;
            try {
                messagesToEnter = Integer.parseInt(nm.trim());
                if (messagesToEnter <= 0)
                    JOptionPane.showMessageDialog(null, "Please enter a positive number.");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number.");
            }
        }

        List<Message> allMessages = new ArrayList<>();
        boolean quit = false;
        int messagesSent = 0;

        while (!quit) {
            String menu = "📋 Choose an option:\n" +
                    "1️⃣ Send message(s)\n" +
                    "2️⃣ View your recent messages\n" +
                    "3️⃣ Exit the app";
            String choice = JOptionPane.showInputDialog(null, menu);
            if (choice == null) return;

            switch (choice.trim()) {
                case "1":
                    if (messagesSent >= messagesToEnter) {
                        JOptionPane.showMessageDialog(null,
                                "🚫 You've reached your message limit of " + messagesToEnter + ".",
                                "Limit Reached", JOptionPane.WARNING_MESSAGE);
                        break;
                    }

                    for (int i = messagesSent; i < messagesToEnter; i++) {
                        String recipient = JOptionPane.showInputDialog(null,
                                String.format("Enter recipient for message %d (include +27):", i + 1));
                        if (recipient == null) break;

                        String messageText = JOptionPane.showInputDialog(null,
                                "Type your message (max 250 characters):");
                        if (messageText == null) break;

                        if (messageText.length() > 250) {
                            JOptionPane.showMessageDialog(null,
                                    "⚠ Message too long! Max allowed is 250 characters.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
                            i--;
                            continue;
                        }

                        JOptionPane.showMessageDialog(null, "✅ Message sent successfully!");

                        Message m = new Message(allMessages.size(), recipient.trim(), messageText);
                        String actionResult = m.sendMessageViaDialog();
                        JOptionPane.showMessageDialog(null, actionResult);

                        if (m.getStatus() == Message.Status.STORED) {
                            try {
                                Message.storeMessagesToJson(
                                        Collections.singletonList(m),
                                        System.getProperty("user.home") + "/stored_messages.json");
                                JOptionPane.showMessageDialog(null,
                                        "💾 Message saved to: " + System.getProperty("user.home") + "/stored_messages.json");
                            } catch (Exception ex) {
                                JOptionPane.showMessageDialog(null,
                                        "Failed to save message: " + ex.getMessage());
                            }
                        }

                        JOptionPane.showMessageDialog(null, m.printMessageDetails());
                        allMessages.add(m);
                        messagesSent++;

                        if (messagesSent >= messagesToEnter) {
                            JOptionPane.showMessageDialog(null,
                                    "🎯 You've sent all your " + messagesToEnter + " messages!");
                            break;
                        }
                    }

                    int totalSent = Message.returnTotalMessages(allMessages);
                    JOptionPane.showMessageDialog(null,
                            "📊 Total messages sent so far: " + totalSent);
                    break;

                case "2":
                    JOptionPane.showMessageDialog(null, "🕓 Feature coming soon!");
                    break;

                case "3":
                    quit = true;
                    break;

                default:
                    JOptionPane.showMessageDialog(null,
                            "❗Invalid choice. Please pick 1, 2 or 3.");
            }
        }

        // === GOODBYE MESSAGE ===
        JOptionPane.showMessageDialog(null,
                "👋 Thanks for chatting with LMQuickChat!\nStay connected, stay bright. 🌟",
                "Goodbye", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void showWelcomeScreen() {
        String logoText = "<html><div style='text-align:center; color:yellow;'>" +
                "<h1 style='font-size:36px;'>LMQuickChat 💬</h1>" +
                "<p style='font-size:18px;'>Connecting people, one message at a time ⚡</p>" +
                "</div></html>";
        JLabel logoLabel = new JLabel(logoText, SwingConstants.CENTER);
        JOptionPane.showMessageDialog(null, logoLabel, "Welcome", JOptionPane.PLAIN_MESSAGE);
    }
}